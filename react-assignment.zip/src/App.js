import React from 'react'; 
import {createStore} from 'redux'
import {Provider} from 'react-redux'
import myReducer from './Reducer/Reducer'
import Container from './Components/Container'

function App() {
  const store=createStore(myReducer);
  return (
    <Provider store={store}>
        <Container></Container>
    </Provider>
  );
}

export default App;
