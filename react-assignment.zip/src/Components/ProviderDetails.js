import React from 'react';
import { connect } from 'react-redux';


function ProvidersDetails(props) {

 const bindServices =(data) =>{ 
     let schedulesIdList=[];

     data.relationships.schedules.data.map((item) =>{
        schedulesIdList.push(item.id);
     })  
     var serviceName= props.providersData.included.filter((item) => item.id==schedulesIdList[0]); 
     if(serviceName[0].attributes.service.toLowerCase() == props.selectedService.toLowerCase())
     {
        return (
            <div style={{marginTop:5}}>
           
            <div className="row providerDetails_Container">
            <div className="col-md-3">
                      <img alt="img"></img>
            </div>
            <div className="col-md-9">
                     <span>Provider Name: {data.attributes.name}</span>
                     <br></br>
                     <span>subspecialties: {data.attributes.subspecialties}</span>
            </div>
        </div>
        </div>
        );
     }
         // return <div>{data.attributes.name +" ========>  "+schedulesIdList}</div>;
     else
         return "";
 }
  return (
   <div>
        <div className="row">
               <span className="ServiceList_header" style={{width:'100%'}}>Result section </span>
       </div>
       {
           props.selectedService != null && 
          props.providersData.data.map(bindServices)       
       }
   </div>
  );
}

const mapStateToProps=(state)=>{
    return {
        providersData : state.providersData,
        selectedService : state.selectedService
    }
}

export default connect(mapStateToProps)(ProvidersDetails);
