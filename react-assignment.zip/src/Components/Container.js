import React, {useEffect} from 'react';
import { connect } from 'react-redux';
import {ApiGetCall} from './APIService'
import ServicesList from './ServicesList'; 
import ProvidersList from './ProvidersList';
import ProvidersDetails from './ProviderDetails'
function Container(props) {

useEffect(() => {  
    LoadServicesData();
    LoadProvidersData();
},[]);
  
 const LoadServicesData = () =>{
     let url="https://api.inquickerstaging.com/v3/winter.inquickerstaging.com/services";
    ApiGetCall(url).then(res => res.json()).then(
            (result) => { 
              props.setServiceData(result.data)
        }); 
 }

 const LoadProvidersData = () =>{
    let url="https://api.inquickerstaging.com/v3/winter.inquickerstaging.com/providers?include=locations%2Cschedules.location&page%5Bnumber%5D=1";
   ApiGetCall(url).then(res => res.json()).then(
           (result) => { 
             props.setProvidersData(result)
       }); 
}

  return (
  <div>
      <nav class="navbar navbar-light bg-light" style={{marginBottom:30}}>
            <span class="navbar-brand mb-0 h1">React Home Assignment</span>
      </nav>
      <div className="container">
     
        <div className='row'>
            <div className="col-md-6">
                <ServicesList></ServicesList>
            </div>
            <div className="col-md-6">
                {props.selectedService == null ?
                <ProvidersList></ProvidersList>
                :<ProvidersDetails></ProvidersDetails>
                }
            </div>
            
        </div>
      </div>
  </div>
  );
}

const mapStateToProps=(state)=>{
    return { 
        selectedService : state.selectedService
    }
}
const mapDispatchToProps = dispatch =>{
    return {
        setServiceData : (data)=> dispatch({type:"setServiceData", data:data}),
        setProvidersData : (data)=> dispatch({type:"setProvidersData", data:data})
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(Container);
