
export const ApiGetCall = (_url)=>{
    return fetch(_url,
        {
            method: 'get',
            headers: {'Content-Type':'application/json'},
             // headers: {'Token':token},
        })
}





