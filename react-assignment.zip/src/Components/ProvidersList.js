import React from 'react';
import { connect } from 'react-redux';


function ProvidersList(props) {

 const bindServices =(data) =>{ 
     
     return <li class="list-group-item">{data.attributes.name}</li>;

 }
  return (
    <div class="list-group">
    <span className="ServiceList_header">Result section - Providers List </span>
    {  
     props.providersData != null && 
          props.providersData.data.map(bindServices)       
    }
    </div>
  
  );
}

const mapStateToProps=(state)=>{ 
    return {
        providersData : state.providersData
    }
}

export default connect(mapStateToProps)(ProvidersList);
