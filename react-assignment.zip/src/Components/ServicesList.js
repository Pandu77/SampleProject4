import React from 'react';
import { connect } from 'react-redux';


function ServicesList(props) {

const serviceClicked=(name) =>{
      props.selectService(name)
}

 const bindServices =(data) =>{
     let activeClass=''; 
     if(props.selectedService != null && data.attributes.name.toLowerCase() == props.selectedService.toLowerCase())
     activeClass='active'
     return <a href="#" class={ " list-group-item "+activeClass} style={{cursor:'pointer', textDecoration:'none'}} onClick={() =>serviceClicked(data.attributes.name)}>{data.attributes.name}</a>;
 }

  return (
   <div class="list-group">
       <span className="ServiceList_header">Control section  
       <button type="button" onClick={() =>serviceClicked(null)} class="btn btn-success" style={{float:'right', height:36}}>Clear Selection</button>
       
       </span>
      
       {
          props.servicesData.map(bindServices)       
       }
        <p className=""> Note: click on service to get provider details</p>
   </div>
  );
}

const mapStateToProps=(state)=>{
    return {
        servicesData : state.servicesData,
        selectedService : state.selectedService
    }
}

const mapDispatchToProps = dispatch =>{
    return {
        selectService : (data)=> dispatch({type:"selectService", data:data}) 
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(ServicesList);
