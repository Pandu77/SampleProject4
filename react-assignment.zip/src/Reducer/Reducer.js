const initialState = {
    servicesData: [],
    providersData: null,
    selectedService: null
}


const reducer=(state=initialState,action)=>{
    switch (action.type) {
        case "setServiceData": {
            console.log(action);
            return Object.assign({}, state, {
                servicesData: action.data
            });
        }
        case "setProvidersData": {
            console.log(action.data)
            return Object.assign({}, state, {
                providersData: action.data
            });
        }
        case "selectService": { 
            return Object.assign({}, state, {
                selectedService: action.data
            });
        }
        default :
         return state;
    }
}
 
export default reducer;
